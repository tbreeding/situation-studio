# Leadership content contracts

Leadership owns this source package and the packed artifact consumed by
Leadership Field Guide and Situation Studio. It provides pure content schemas,
canonical snapshot primitives, graph validation, safe MDX compilation,
situation-scoped artifact paths, and authored-to-physical practice identity
rules.

`0.2.0` writes validation policy v2 snapshots. Readers continue to accept the
exact legacy policy hash so the additive Leadership-first deployment can read
the current official release while producers move to v2.
