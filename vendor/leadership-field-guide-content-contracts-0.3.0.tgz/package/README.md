# Leadership content contracts

Leadership owns this source package and the packed artifact consumed by
Leadership Field Guide and Situation Studio. It provides pure content schemas,
canonical snapshot primitives, graph validation, safe MDX compilation,
situation-scoped artifact paths, and authored-to-physical practice identity
rules.

`0.3.0` owns the pure `compilePublishableSituationSnapshot` publication
boundary. It compiles a complete, typed situation snapshot against immutable
base manifest/body inputs; validates managed component properties through the
MDX AST; and returns exact candidate bytes, hashes, typed projection data,
field-path diagnostics, and affected-route expectations.

Producers must first call the base-independent
`validatePublishableSituationSnapshot`. It applies the same intrinsic gate used
by the compiler and returns a normalized snapshot hash plus canonical
frontmatter, MDX, situation-artifact, and scoped-artifact descriptors. Scoped
descriptors include their exact bytes, hash, length, path, media type, encoding,
visibility, owner, and fork provenance. Save, review materialization, proposal
application, and publication preflight can therefore reject relationship or
managed-component drift before a Leadership base release is needed.

`PublishableSituationSnapshot.visibility` is intended runtime visibility and
is exactly `PUBLIC` or `RETIRED`. A producer's draft lifecycle state is a
separate concern; producers must not store `UNPUBLISHED` here and silently
convert it during preflight.

New snapshots use validation policy v3. Readers continue to accept the exact
v2 and v1 policy hashes so official historical releases remain readable during
the producer upgrade. Historical policy acceptance does not make those older
policies valid for newly compiled candidates.

The v1 compiler preserves existing global guide membership and rejects edits
that would add or remove it. Situation-scoped guide and practice bodies are
supported with immutable-base provenance and are excluded from global route
and graph derivation. Situation-scoped source overrides are intentionally
rejected until Leadership has a per-reference source identity instead of the
catalog-wide `source:catalog` identity.
