# Leadership situation contract

Leadership-owned, versioned contract shared by Leadership Field Guide and
Situation Studio. It defines canonical situation bundles, section round trips,
allowlisted MDX validation, render primitives, typed projection checks, and
situation-scoped artifact resolution.
